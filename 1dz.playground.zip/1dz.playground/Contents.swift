import UIKit

enum eyesColor:String{
    case brown
    case blue
    case green
}

enum hair:String{
    case brown
    case black
    case blond
}

class Human{
    let year:Int
    let pol:String
    var eyesColor:eyesColor = .blue
    var hair:hair = .blond
    
    init(year:Int, pol:String){
        self.year = year
        self.pol = pol
    }
    func talk(){
        print("Здравствуйте")
    }
}



class Librarian:Human{
    let experience:Int
    var glasses:Bool = true
    let name:String
    
    init(year:Int, pol:String, experience:Int, name:String){
        self.experience = experience
        self.name = name
        super.init(year: year, pol:pol)
    }
    override func talk() {
        print("Какая книга вам нужна?")
    }
}
    
let librarian = Librarian(year: 76, pol: "Girl", experience: 20, name: "Nina")

class Reader:Human{
    var read:Bool = true
    let readBooks:Int
    
    init(year:Int, pol:String, readBooks:Int){
        self.readBooks = readBooks
        
        super.init(year:year, pol:pol)
    }
                                                
    override func talk() {
        print("Мне нужны 2 книги")
    }
    
}
let reader = Reader(year: 19, pol: "Men", readBooks: 3)


struct Book{
    let title:String
    let pages:Int
}



class Security:Human{
    var weapon:Bool = false
    let form::String
    let experience:Int
    
    init(year:Int, pol:String,form:String,experience:Int){
        self.form = form
        self.experience = experience
        
        super.init(year:year,pol:pol)
    }
    override func talk() {
        print("Здравствуйте")
    }
}

struct Phone{
    let processor:String
    let buttons:Int
}

struct Computer{
    let processor:String
    let firm:String
    
}

class cleaning:Human{
    let form:String
    let mop:Bool = true
    
    init(year:Int, pol:String, form:String){
        self.form = form
        
    super.init(year:year,pol:pol)
    }
    override func talk() {
        print("Мне нужно здесь убрать")
}
